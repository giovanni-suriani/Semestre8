* A simulação do MODELSIM se encontra na pasta do mesmo. Lembre-se de alterar o caminho para os arquivos
.mem que suprem o estado inicial.