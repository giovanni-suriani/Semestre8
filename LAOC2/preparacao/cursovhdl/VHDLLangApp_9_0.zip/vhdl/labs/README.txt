This is the README file for:

  VHDL Language And Application- version 26.0

After installing the course, source the .cshrc file. This shell script sets the path variables to find executables and libraries. You must source this script in shell in which you run the
tools. MODIFY THIS SCRIPT AS NEEDED FOR YOUR PLATFORM AND SHELLS.

The software products and versions required for this course are:

  -> Xcelium Simulator    21.1
  -> GENUS Synthesis Tool 20.1

Before you run any Cadence software, verify your patch level and install
any missing required patches, enter:
  <IUS_Install_Dir>/tools/bin/checkSysConf XCELIUM211
  <IUS_Install_Dir>/tools/bin/checkSysConf GENUS201

Although you can expect the Cadence software to work on any supported platform,
the course lab database has been tested only with the above software on:
  Linux RH EE 6.5
  Solaris 10


Additional notes :
   - Lab -1-2 gives the design diagram of the Alarm Clock for study to understand and explore since it will be used in all the labs till lab21. The labs flow would be to develop each component of this Alarm Clock design starting form lab6-1 and then go on to verify the whole Alarm Clock design in lab19 and 21.Please go through this lab1-2 design carefully so that you understand the purpose of each of the labs till lab21.

